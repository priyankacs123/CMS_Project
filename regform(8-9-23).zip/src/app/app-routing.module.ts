import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmpLoginComponent } from './employee-details/emp-login/emp-login.component';

const routes: Routes = [{ path: 'emp-login', component: EmpLoginComponent},];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
