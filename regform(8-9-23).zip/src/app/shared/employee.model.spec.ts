import { Epmloyee } from './employee.model';

describe('Employee', () => {
  it('should create an instance', () => {
    expect(new Epmloyee()).toBeTruthy();
  });
});
