﻿namespace CMS_Project.CMS_Models
{
    public class Job
    {
        public int JobId { get; set; }

        public string JobRole { get; set; }
    }
}
