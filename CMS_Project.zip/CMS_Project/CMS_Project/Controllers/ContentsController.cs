﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CMS_Project.CMS_Models;

namespace CMS_Project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContentsController : ControllerBase
    {
        private readonly CMS_CommonContext _dbContext;

        public ContentsController(CMS_CommonContext dbContext)
        {
            _dbContext = dbContext;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Contents>>> GetContents()
        {
            var contentItems = await _dbContext.Contents.ToListAsync();

            if (contentItems == null || contentItems.Count == 0)
                return NotFound();

            return contentItems;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Contents>> GetContents(int id)
        {
            var contentItem = await _dbContext.Contents.FindAsync(id);

            if (contentItem == null)
                return NotFound();

            return contentItem;
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutContents(int id, Contents contents)
        {
            if (id != contents.ContentID)
                return BadRequest();

            _dbContext.Entry(contents).State = EntityState.Modified;

            try
            {
                await _dbContext.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ContentsExists(id))
                    return NotFound();

                throw;
            }

            return NoContent();
        }

        [HttpPost]
        public async Task<ActionResult<Contents>> PostContents(Contents contents)
        {
            _dbContext.Contents.Add(contents);
            await _dbContext.SaveChangesAsync();

            return CreatedAtAction("GetContents", new { id = contents.ContentID }, contents);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteContents(int id)
        {
            var contentItem = await _dbContext.Contents.FindAsync(id);

            if (contentItem == null)
                return NotFound();

            _dbContext.Contents.Remove(contentItem);
            await _dbContext.SaveChangesAsync();

            return NoContent();
        }

        private bool ContentsExists(int id)
        {
            return _dbContext.Contents.Any(e => e.ContentID == id);
        }
    }
}
